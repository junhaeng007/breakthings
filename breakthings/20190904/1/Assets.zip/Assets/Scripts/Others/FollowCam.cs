﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowCam : MonoBehaviour
{
    private Transform playerTr;
    private Transform cameraTr;
    [SerializeField]
    private float followSpeed;

    void Start()
    {
        playerTr = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        cameraTr = transform;
    }

   
    void LateUpdate()
    {
        cameraTr.position = new Vector3(playerTr.position.x, playerTr.position.y, -10.0f);
    }
    
    /*
    //부드럽게 따라가기
    void Update()
    {
        cameraTr.position = Vector3.Lerp(cameraTr.position, playerTr.position, followSpeed * Time.deltaTime);
        cameraTr.Translate(0, 0, -10); //카메라를 원래 z축으로 이동
    }
    */
}
