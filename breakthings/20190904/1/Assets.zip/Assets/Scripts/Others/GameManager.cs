﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct ItemEffect
{
    public float meatHp;
    public float appleMp;
}

public struct NumObject
{
    public byte numItem;
    public byte numSpOb;
}

public enum Stage
{
    First_Vegeta
}

public class GameManager : MonoBehaviour
{
    public static GameManager instance = null;  //싱글턴 패턴 생성을 위한 GameManager 타입의 전역 변수
    public ItemEffect itemEffect;
    public NumObject numObject;
    public Stage stage;
    public byte stack;
   
    void Awake()
    {
        instance = this;                        //별도의 GetComponent<GameManager>() 메소드 사용 불필요
        itemEffect.meatHp = 20.0f;
        itemEffect.appleMp = 40.0f;
    }

    void Start()
    {
        stack = 0;
    }

    
}
