﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    private Obstacle obCs;
    private Vector2 obVt2;

    //아이템 관련
    private const byte createItemProb = 75; //생성확률 1.3%
    private int inputItemProb;             //랜덤수 대입
    private bool boolItemProb;              //확률만족 여부

    void OnCollisionEnter2D(Collision2D coll)
    {
        ////////////////일반 장애물이라면//////////////////////////
        if(coll.collider.CompareTag("Obstacle"))
        {
            obCs = coll.collider.gameObject.GetComponent<Obstacle>();
            obVt2 = coll.transform.position;
            ChangePosition(coll, gameObject.name);
            inputItemProb = Random.Range(1, createItemProb + 1);

            if(obCs.coolingIsDone)
            {
                obCs.coolingIsDone = false;
                obCs.leftCoolDown = 0.0f;

                //1.3%확률로 장애물 대신 아이템 생성
                if(inputItemProb == 1 && GameManager.instance.numObject.numItem < Stage_BasicMgr.instance.maxItemPool)
                {
                    var _item = Stage_BasicMgr.instance.GetItem();
                    if(_item != null)
                    {
                        _item.transform.SetPositionAndRotation(obVt2, Quaternion.Euler(0, 0, 0));
                        _item.SetActive(true);
                    }
                }

                //3.9%확률로 장애물 대신 특별 장애물 생성
                else if((inputItemProb >= 2 && inputItemProb <= 4) && GameManager.instance.numObject.numItem < Stage_BasicMgr.instance.maxSpObPool)
                {
                    var _spObstacle = Stage_BasicMgr.instance.GetSpObstacle();
                    if(_spObstacle != null)
                    {
                        _spObstacle.transform.SetPositionAndRotation(obVt2, Quaternion.Euler(0, 0, 0));
                        _spObstacle.SetActive(true);
                    }
                }
                
                //나머지 확률로 장애물 생성
                else
                {
                    var _obstacle = Stage_BasicMgr.instance.GetObstacle();
                    if(_obstacle != null)
                    {
                        _obstacle.transform.SetPositionAndRotation(obVt2, Quaternion.Euler(0, 0, 0));
                        _obstacle.SetActive(true);
                    }
                }
            }
        }
        ////////////////---일반 장애물이라면---//////////////////////////

    }

    void ChangePosition(Collision2D _coll, string _name)
    {
        switch(_name)
        {
            case "NorthWall":
                obVt2.x = _coll.transform.position.x - 0.5f;
                obVt2.y = _coll.transform.position.y - 0.5f;
                break;
            case "EastWall":
                obVt2.x = _coll.transform.position.x - 0.5f;
                obVt2.y = _coll.transform.position.y + 0.5f;
                break;
            case "SouthWall":
                obVt2.x = _coll.transform.position.x - 0.5f;
                obVt2.y = _coll.transform.position.y + 0.5f;
                break;
            case "WestWall":
                obVt2.x = _coll.transform.position.x + 0.5f;
                obVt2.y = _coll.transform.position.y + 0.5f;
                break;
        }
    }
}
