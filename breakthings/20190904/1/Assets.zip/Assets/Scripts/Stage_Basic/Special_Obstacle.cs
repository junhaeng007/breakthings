﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Special_Obstacle : MonoBehaviour
{
    private Rigidbody2D rb2D;
    private SpriteRenderer spriteRenderer;

    //특수 장애물 결정 요소
    public Sprite[] spObSprite;
    private const byte denominatorProb = 2;
    private int inputSpObDecideProb;
    private bool boolSpObDecideProb;

    //특수 장애물 이동 벡터
    private Vector2 spObDir;
    private float spObDir_x;
    private float spObDir_y;
    private ushort speed;
    private readonly ushort speed_Default = 750;
    private readonly ushort speed_Red = 2000;

    private bool bumpToWall = false;                    //벽에 부딪혔을 때
    private byte numBump = 0;                           //벽에 부딪힌 횟수(검은 장애물 전용)

    void Awake()
    {
        rb2D = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    //특수 장애물 생성시
    void OnEnable()
    {
        GameManager.instance.numObject.numSpOb++;
        inputSpObDecideProb = Random.Range(1, denominatorProb + 1);

        /////////////스프라이트 결정////////////
        //검은 장애물
        if(inputSpObDecideProb == 1)
        {
            spriteRenderer.sprite = spObSprite[0];
            tag = "Obstacle_Black";
            speed = speed_Default;
        }
        //붉은 장애물
        else
        {
            spriteRenderer.sprite = spObSprite[1];
            tag = "Obstacle_Red";
            speed = speed_Red;
        }
        /////////////스프라이트 결정////////////

        //이동 방향 설정
        while(true)
        {
            spObDir_x = Random.Range(-5, 5);
            if(spObDir_x != 0.0f) break;
        }
        while(true)
        {
            spObDir_y = Random.Range(-5, 5);
            if(spObDir_y != 0.0f) break;
        }

        spObDir = new Vector2(spObDir_x, spObDir_y);
        spObDir.Normalize();

        //이동 시작
        rb2D.AddForce(spObDir * speed);

    }

    void OnDisable()
    {
        tag = "Obstacle";
        speed = 0;
        numBump = 0;
        GameManager.instance.numObject.numSpOb--;
    }

    void Update()
    {
        if(bumpToWall)
        {
            spObDir = new Vector2(spObDir_x, spObDir_y);
            spObDir.Normalize();
            rb2D.AddForce(spObDir * speed);
            bumpToWall = false;
        }
    }
    /*
    void OnTriggerEnter2D(Collider2D coll)
    {
        //플레이어와 부딪혔을 때
        if(coll.CompareTag("Player"))
        {
            Player.instance.health -= 40;
        }
    }*/

    void OnCollisionEnter2D(Collision2D coll)
    {
        //벽에 부딪혔을 때
        if(coll.collider.CompareTag("Wall"))
        {

            //특별 장애물이 검은 장애물일 경우
            if(inputSpObDecideProb == 1) numBump++;

            //검은 장애물이 10번 이상 튕기면 파괴
            if(numBump >= 10) gameObject.SetActive(false);

            switch(coll.collider.name)
            {
                case "NorthWall":
                    if(spObDir_x < 0 && spObDir_y > 0)
                    {
                        spObDir_x = Random.Range(-5, 0);
                        spObDir_y = Random.Range(-5, 0);
                    }
                    else if(spObDir_x > 0 && spObDir_y > 0)
                    {
                        spObDir_x = Random.Range(1, 6);
                        spObDir_y = Random.Range(-5, 0);
                    }
                    break;

                case "EastWall":
                    if(spObDir_x > 0 && spObDir_y < 0)
                    {
                        spObDir_x = Random.Range(-5, 0);
                        spObDir_y = Random.Range(-5, 0);
                    }
                    else if(spObDir_x > 0 && spObDir_y > 0)
                    {
                        spObDir_x = Random.Range(-5, 0);
                        spObDir_y = Random.Range(1, 6);
                    }
                    break;

                case "SouthWall":
                    if(spObDir_x < 0 && spObDir_y < 0)
                    {
                        spObDir_x = Random.Range(-5, 0);
                        spObDir_y = Random.Range(1, 6);
                    }
                    else if(spObDir_x > 0 && spObDir_y < 0)
                    {
                        spObDir_x = Random.Range(1, 6);
                        spObDir_y = Random.Range(1, 6);
                    }
                    break;

                case "WestWall":
                    if(spObDir_x < 0 && spObDir_y > 0)
                    {
                        spObDir_x = Random.Range(1, 6);
                        spObDir_y = Random.Range(1, 6);
                    }
                    else if(spObDir_x < 0 && spObDir_y < 0)
                    {
                        spObDir_x = Random.Range(1, 6);
                        spObDir_y = Random.Range(-5, 0);
                    }
                    break;
            }
            bumpToWall = true;
        }
    }
}