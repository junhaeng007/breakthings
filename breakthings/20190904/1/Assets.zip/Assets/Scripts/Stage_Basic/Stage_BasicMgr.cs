﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage_BasicMgr : MonoBehaviour
{
    public static Stage_BasicMgr instance = null;  //싱글턴 패턴 생성을 위한 Stage_BasicMgr 타입의 전역 변수
    public GameObject obPrefab;
    public GameObject spObPrefab;
    public GameObject itemPrefab;
    private GameObject pools;   //전체 풀링 부모 오브젝트
    
    //장애물 최초 생성좌표
    private float[] ob_x = { 40, -40, -40, 40, 0, 0, 0, 0 };
    private float[] ob_y = { 25, -25, 25, -25, 25, -25, 50, -50};

    //Obstacle풀링
    [SerializeField, Tooltip("최초 Obstalce 개수(최대 8개)")]
    private byte startObNum;
    [SerializeField, Tooltip("Obstacle 최대 개수")]
    private byte maxObPool;
    private List<GameObject> obPool = new List<GameObject>();

    //Special Obstacle풀링
    [Tooltip("Special Obstacle 최대 개수")]
    public byte maxSpObPool;
    private List<GameObject> spObPool = new List<GameObject>();

    //Item풀링
    [Tooltip("Item 최대 개수")]
    public byte maxItemPool;
    private List<GameObject> itemPool = new List<GameObject>();

    [Tooltip("Obstacle 풀링 On/Off(개발자 전용)")]
    public bool isPooling = true;

    void Awake()
    {
        instance = this;
    }

    void Start()
    {
        pools = new GameObject("Pools");
        if(isPooling)
            CreatePooling();
        Stage_Basic();
        
    }

    void Stage_Basic()
    {
        byte startObCount = 0;
        while(startObCount < startObNum)
        {
            var _obstacle = GetObstacle();
            if(_obstacle != null)
            {
                _obstacle.transform.SetPositionAndRotation(new Vector3(ob_x[startObCount], ob_y[startObCount], 0), Quaternion.Euler(0, 0, 0));
                _obstacle.SetActive(true);
            }
            startObCount++;
        }
    }

    public GameObject GetObstacle()
    {
        for(int i = 0; i < obPool.Count; i++)
        {
            if(obPool[i].activeSelf == false)
                return obPool[i];
        }
        return null;
    }

    public GameObject GetSpObstacle()
    {
        for(int i = 0; i < spObPool.Count; i++)
        {
            if(spObPool[i].activeSelf == false)
                return spObPool[i];
        }
        return null;
    }

    public GameObject GetItem()
    {
        for(int i = 0; i < itemPool.Count; i++)
        {
            if(itemPool[i].activeSelf == false)
                return itemPool[i];
        }
        return null;
    }

    public void CreatePooling()
    {
        CreatePoolingForObstacle();
        CreatePoolingForSpecialObstacle();
        CreatePoolingForItem();
    }

    public void CreatePoolingForObstacle()
    {
        GameObject obstaclePools = new GameObject("ObstaclePools");
        obstaclePools.transform.SetParent(pools.transform);
        for(int i = 0; i < maxObPool; i++)
        {
            var ob = Instantiate<GameObject>(obPrefab, obstaclePools.transform);
            ob.name = "Obstacle_" + i.ToString("00");
            ob.SetActive(false);
            obPool.Add(ob);
        }
    }

    public void CreatePoolingForSpecialObstacle()
    {
        GameObject sp_ObstaclePools = new GameObject("Special_ObstaclePools");
        sp_ObstaclePools.transform.SetParent(pools.transform);
        for(int i = 0; i < maxSpObPool; i++)
        {
            var spOb = Instantiate<GameObject>(spObPrefab, sp_ObstaclePools.transform);
            spOb.name = "Special_Obstacle_" + i.ToString("00");
            spOb.SetActive(false);
            spObPool.Add(spOb);
        }
    }

    public void CreatePoolingForItem()
    {
        GameObject itemPools = new GameObject("ItemPools");
        itemPools.transform.SetParent(pools.transform);
        for(int i = 0; i < maxItemPool; i++)
        {
            var item = Instantiate<GameObject>(itemPrefab, itemPools.transform);
            item.name = "Item_" + i.ToString("00");
            item.SetActive(false);
            itemPool.Add(item);
        }
    }
}
