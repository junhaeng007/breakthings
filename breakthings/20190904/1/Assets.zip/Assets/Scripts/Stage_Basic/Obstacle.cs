﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour
{
    private Rigidbody2D rb2D;

    //장애물 이동 벡터
    private Vector2 obDir;
    private float obDir_x;
    private float obDir_y;
    private ushort speed = 750;

    //장애물 분열
    private bool bumpToWall = false;                            //벽에 부딪혔을 때
    private bool coolDownStart = true;                          //쿨다운 시작 여부
    [System.NonSerialized] public float coolDownMax = 3.0f;     //장애물 생성 쿨타임
    [System.NonSerialized] public float leftCoolDown;           //생성 남은 쿨타임
    [System.NonSerialized] public bool coolingIsDone = false;   //leftCoolDown == coolDownMax -> true

    void Awake()
    {
        rb2D = GetComponent<Rigidbody2D>();
    }

    //장애물 생성(분열)시
    void OnEnable()
    {
        //이동 방향 설정
        while(true)
        {
            obDir_x = Random.Range(-5, 5);
            if(obDir_x != 0.0f) break;
        }
        while(true)
        {
            obDir_y = Random.Range(-5, 5);
            if(obDir_y != 0.0f) break;
        }

        obDir = new Vector2(obDir_x, obDir_y);
        obDir.Normalize();

        //이동 시작
        rb2D.AddForce(obDir * speed);

        //쿨타임 0초로 초기화
        leftCoolDown = 0.0f;
    }

    void Update()
    {
        if(bumpToWall)
        {
            obDir = new Vector2(obDir_x, obDir_y);
            obDir.Normalize();
            rb2D.AddForce(obDir * speed);
            coolDownStart = true;
            bumpToWall = false;
        }
        if(coolDownStart)
        {
            CoolingTimeBegin();
        }
    }
    /*
    void OnTriggerEnter2D(Collider2D coll)
    {
        //플레이어와 부딪혔을 때
        if(coll.CompareTag("Player"))
        {
            Player.instance.health -= 40;
        }
    }*/

    void OnCollisionEnter2D(Collision2D coll)
    {
        if(coll.collider.CompareTag("Wall"))
        {
            switch(coll.collider.name)
            {
                case "NorthWall":
                    if(obDir_x < 0 && obDir_y >= 0)
                    {
                        obDir_x = Random.Range(-5, 0);
                        obDir_y = Random.Range(-5, 0);
                    }
                    else if(obDir_x >= 0 && obDir_y >= 0)
                    {
                        obDir_x = Random.Range(1, 6);
                        obDir_y = Random.Range(-5, 0);
                    }
                    break;

                case "EastWall":
                    if(obDir_x >= 0 && obDir_y < 0)
                    {
                        obDir_x = Random.Range(-5, 0);
                        obDir_y = Random.Range(-5, 0);
                    }
                    else if(obDir_x >= 0 && obDir_y >= 0)
                    {
                        obDir_x = Random.Range(-5, 0);
                        obDir_y = Random.Range(1, 6);
                    }
                    break;

                case "SouthWall":
                    if(obDir_x < 0 && obDir_y < 0)
                    {
                        obDir_x = Random.Range(-5, 0);
                        obDir_y = Random.Range(1, 6);
                    }
                    else if(obDir_x >= 0 && obDir_y < 0)
                    {
                        obDir_x = Random.Range(1, 6);
                        obDir_y = Random.Range(1, 6);
                    }
                    break;

                case "WestWall":
                    if(obDir_x < 0 && obDir_y >= 0)
                    {
                        obDir_x = Random.Range(1, 6);
                        obDir_y = Random.Range(1, 6);
                    }
                    else if(obDir_x < 0 && obDir_y < 0)
                    {
                        obDir_x = Random.Range(1, 6);
                        obDir_y = Random.Range(-5, 0);
                    }
                    break;
            }
            bumpToWall = true;
        }
    }

    void CoolingTimeBegin()
    {
        if(coolDownMax >= leftCoolDown && !coolingIsDone)
            leftCoolDown += Time.deltaTime;
        else
        {
            coolingIsDone = true;
            coolDownStart = false;
        }
    }
}
