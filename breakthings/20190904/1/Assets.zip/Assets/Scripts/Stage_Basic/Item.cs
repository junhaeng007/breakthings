﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    private Rigidbody2D rb2D;
    private SpriteRenderer spriteRenderer;

    //아이템 결정 요소
    public Sprite[] itemSprite;       //0 = 고기, 1 = 사과
    private const byte denominatorProb = 5;  //사과(80%), 고기(20%)
    private int inputItemDecideProb;
    private bool boolItemDecideProb;

    //아이템 이동 벡터
    private Vector2 itemDir;
    private float itemDir_x;
    private float itemDir_y;
    private ushort speed = 400;

    /*아이템 효과(는 GameObject에서)
    private const byte chargeMana = 40;
    private const byte chargeHealth = 20;*/

    private bool bumpToWall = false;   //벽에 부딪혔을 때


    void Awake()
    {
        rb2D = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    //아이템 생성시
    void OnEnable()
    {
        GameManager.instance.numObject.numItem++;
        inputItemDecideProb = Random.Range(1, denominatorProb + 1);

        /////////////스프라이트 결정////////////
        //20%확률로 고기
        if(inputItemDecideProb == 1)
        {
            spriteRenderer.sprite = itemSprite[0];
            tag = "Item_Meat";
            
        }
        //80%확률로 사과
        else
        {
            spriteRenderer.sprite = itemSprite[1];
            tag = "Item_Apple";
        }
        /////////////스프라이트 결정////////////

        //이동 방향 설정
        while(true)
        {
            itemDir_x = Random.Range(-5, 5);
            if(itemDir_x != 0.0f) break;
        }
        while(true)
        {
            itemDir_y = Random.Range(-5, 5);
            if(itemDir_y != 0.0f) break;
        }

        itemDir = new Vector2(itemDir_x, itemDir_y);
        itemDir.Normalize();

        //이동 시작
        rb2D.AddForce(itemDir * speed);
    }

    void OnDisable()
    {
        GameManager.instance.numObject.numItem--;
        tag = "Item";
    }

    void Update()
    {
        if(bumpToWall)
        {
            itemDir = new Vector2(itemDir_x, itemDir_y);
            itemDir.Normalize();
            rb2D.AddForce(itemDir * speed);
            bumpToWall = false;
        }
    }

    /*
    void OnTriggerEnter2D(Collider2D coll)
    {
        //플레이어와 부딪혔을 때
        if(coll.CompareTag("Player"))
        {
            //고기일 때
            if(inputItemDecideProb == 1)
            {
                if(Player.instance.health < Player.instance.maxHealth)
                {
                    Player.instance.health += chargeHealth;
                    gameObject.SetActive(false);
                }
            }
            //사과일 때
            else
            {
                if(Player.instance.mana < Player.instance.maxMana)
                {
                    Player.instance.mana += chargeMana;
                    gameObject.SetActive(false);
                }
            }
        }
    }*/

    void OnCollisionEnter2D(Collision2D coll)
    {
        if(coll.collider.CompareTag("Wall"))
        {
            switch(coll.collider.name)
            {
                case "NorthWall":
                    if(itemDir_x < 0 && itemDir_y > 0)
                    {
                        itemDir_x = Random.Range(-5, 0);
                        itemDir_y = Random.Range(-5, 0);
                    }
                    else if(itemDir_x > 0 && itemDir_y > 0)
                    {
                        itemDir_x = Random.Range(1, 6);
                        itemDir_y = Random.Range(-5, 0);
                    }
                    break;

                case "EastWall":
                    if(itemDir_x > 0 && itemDir_y < 0)
                    {
                        itemDir_x = Random.Range(-5, 0);
                        itemDir_y = Random.Range(-5, 0);
                    }
                    else if(itemDir_x > 0 && itemDir_y > 0)
                    {
                        itemDir_x = Random.Range(-5, 0);
                        itemDir_y = Random.Range(1, 6);
                    }
                    break;

                case "SouthWall":
                    if(itemDir_x < 0 && itemDir_y < 0)
                    {
                        itemDir_x = Random.Range(-5, 0);
                        itemDir_y = Random.Range(1, 6);
                    }
                    else if(itemDir_x > 0 && itemDir_y < 0)
                    {
                        itemDir_x = Random.Range(1, 6);
                        itemDir_y = Random.Range(1, 6);
                    }
                    break;

                case "WestWall":
                    if(itemDir_x < 0 && itemDir_y > 0)
                    {
                        itemDir_x = Random.Range(1, 6);
                        itemDir_y = Random.Range(1, 6);
                    }
                    else if(itemDir_x < 0 && itemDir_y < 0)
                    {
                        itemDir_x = Random.Range(1, 6);
                        itemDir_y = Random.Range(-5, 0);
                    }
                    break;
            }
            bumpToWall = true;
        }
    }
}
