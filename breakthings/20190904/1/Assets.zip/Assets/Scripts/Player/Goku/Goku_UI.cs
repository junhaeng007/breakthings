﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Goku_UI : CoolDown
{
    [System.Serializable]
    public struct Portrait
    {
        public GameObject normalObj;
        public GameObject kaiokenObj;
        [System.NonSerialized] public Image normalImg;
        [System.NonSerialized] public Image kaiokenImg;
    }

    [System.Serializable]
    public struct SkillBtn
    {
        public GameObject khhObj;
        public GameObject k_KhhObj;
        public Image khhImg;
        public GameObject seObj;
        public GameObject k_SeObj;
        public Image seImg;
        public Image kaiokenImg;
    }

    [System.Serializable]
    public struct SliderGauage
    {
        public Slider manaGauage;
        public Slider kaiokenGauage;
        public Slider avoidanceGauage;
    }

    private Goku goku;
    [SerializeField] private Portrait portrait;
    [SerializeField] private SliderGauage sliderGauage;
    [SerializeField] private SkillBtn skillBtn;

    private Color color;

    void Start()
    {
        goku = GameObject.Find("Goku").GetComponent<Goku>();
        portrait.normalImg = portrait.normalObj.GetComponent<Image>();
        portrait.kaiokenImg = portrait.kaiokenObj.GetComponent<Image>();

        sliderGauage.manaGauage.maxValue = goku.stat.maxMana;
        sliderGauage.kaiokenGauage.maxValue = goku.kaioken.maxT;
        sliderGauage.avoidanceGauage.maxValue = goku.teleport.maxC;
        color.r = 1.0f; color.g = 1.0f; color.b = 1.0f; color.a = 1.0f;
    }

    public void CoolTimeUI_Khh()
    {
        CoolTime(skillBtn.khhImg, goku.khh.maxC, goku.khh.leftC);
    }

    public void CoolTimeUI_SE()
    {
        CoolTime(skillBtn.seImg, goku.se.maxC, goku.se.leftC);
    }

    public void CoolTimeUI_Kaioken()
    {
        CoolTime(skillBtn.kaiokenImg, goku.kaioken.maxC, goku.kaioken.leftC);
    }

    public void SetActiveUI(bool b)
    {
        portrait.normalObj.SetActive(!b);
        skillBtn.khhObj.SetActive(!b);
        skillBtn.seObj.SetActive(!b);

        portrait.kaiokenObj.SetActive(b);
        skillBtn.k_KhhObj.SetActive(b);
        skillBtn.k_SeObj.SetActive(b);
    }

    public void OnViewHealthGauage(float _health)
    {
        color.g = _health / 100.0f;
        color.b = _health / 100.0f;
        portrait.normalImg.color = color;
        portrait.kaiokenImg.color = color;
    }

    public void OnViewManaGauage(float _mana)
    {
        sliderGauage.manaGauage.value = _mana;
    }

    public void OnViewKaiokenGauage(float _time)
    {
        sliderGauage.kaiokenGauage.value = _time;
    }

    public void OnViewAvoidanceGauage(float _maxTime, float _leftTime)
    {
        sliderGauage.avoidanceGauage.value = _maxTime - _leftTime;
    }
}