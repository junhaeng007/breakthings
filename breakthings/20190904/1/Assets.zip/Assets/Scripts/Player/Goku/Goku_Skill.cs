﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Goku_Skill : MonoBehaviour
{
    private Goku goku;
    void Start()
    {
        goku = GameObject.Find("Goku").GetComponent<Goku>();
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if(coll.CompareTag("Obstacle") || coll.CompareTag("Obstacle_Red"))
        {
            coll.gameObject.SetActive(false);
            GameManager.instance.stack += 1;
            if(gameObject.CompareTag("KaiokenShield"))
            {
                goku.kaioken.leftT -= 2.0f;
                GameManager.instance.stack -= 1;
            }
        }
    }
}
