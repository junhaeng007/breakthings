﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goku : Player
{
    [System.Serializable]
    public struct Kamehameha
    {
        [Tooltip("쿨다운")] public float maxC;
        [Tooltip("마나 사용량")] public float mana;
        [System.NonSerialized] public float magniCool;
        [System.NonSerialized] public float leftC;
    }
    [System.Serializable]
    public struct SpiritExplosion
    {
        [Tooltip("쿨다운")] public float maxC;
        [Tooltip("마나 사용량")] public float mana;
        [System.NonSerialized] public float magniCool;
        [System.NonSerialized] public float leftC;
    }
    [System.Serializable]
    public struct Kaioken
    {
        [Tooltip("쿨다운")]
        public float maxC;
        [Tooltip("지속시간")]
        public float maxT;
        [Tooltip("증가된 마나리젠")]
        public float increaseRegenMana;
        [Tooltip("증가된 속도")]
        public float increaseSpeed;
        [Tooltip("Q스킬 쿨타임 감소 배율")]
        public float magni_Q_Cool;
        [Tooltip("W스킬 쿨타임 감소 배율")]
        public float magni_W_Cool;
        [System.NonSerialized] public float returnRegenMana;
        [System.NonSerialized] public float returnSpeed;
        [System.NonSerialized] public float returnMagniCool;
        [System.NonSerialized] public float leftC;
        [System.NonSerialized] public float leftT;
    }
    [System.Serializable]
    public struct Teleport
    {
        [Tooltip("쿨다운")]
        public float maxC;
        [Tooltip("지속시간(선딜레이 제외)")]
        public float maxT;
        [Tooltip("증가된 속도")]
        public float increaseSpeed;
        [System.NonSerialized] public float returnSpeed;
        [System.NonSerialized] public float leftC;
        [System.NonSerialized] public float leftT;
    }

    private Transform tr;
    [System.NonSerialized]
    public Animator animator;

    private Goku_SE goku_SE;
    private Goku_UI goku_UI;

    //계왕권 오오라 오브젝트
    private GameObject kaiokenAuraObj;
    //박스 콜라이더 2D
    private BoxCollider2D bC2D;

    //스킬 자원 변수
    public Kamehameha khh;
    public SpiritExplosion se;
    public Kaioken kaioken;
    public Teleport teleport;

    //스킬 Boolean 변수
    [System.NonSerialized] public bool canUseKhh = false;                   //에네르기파 가능 여부
    [System.NonSerialized] public bool canUseSe = false;                    //기합폭발 가능 여부
    [System.NonSerialized] public bool canUseKaioken = false;               //계왕권 가능 여부
    [System.NonSerialized] public bool canUseTeleport = false;              //순간이동 가능 여부

    //애니메이터 컨트롤러에 정의한 파라미터의 해시값을 미리 추출
    private readonly int hashMove = Animator.StringToHash("Move");
    private readonly int hashKhh = Animator.StringToHash("Kamehameha");
    private readonly int hashSe = Animator.StringToHash("SpiritExplosion");
    private readonly int hashKaioken = Animator.StringToHash("Kaioken");
    private readonly int hashTeleport = Animator.StringToHash("Teleport");
    private readonly int hashGuard = Animator.StringToHash("Guard");
    private readonly int hashTeleportingIsOver = Animator.StringToHash("TeleportingIsOver");
    private readonly int hashTeleportMode = Animator.StringToHash("TeleportMode");

    void Awake()
    {
        tr = transform;
        moveVt = Vector2.zero;

        //스텟, 스킬 변수 초기화
        stat.returnSpeed = stat.moveSpeed;
        khh.leftC = khh.maxC;
        se.leftC = se.maxC;
        kaioken.leftC = 15.0f;
        kaioken.returnSpeed = stat.moveSpeed;
        kaioken.returnRegenMana = stat.regenMana;
        kaioken.returnMagniCool = 1.0f;
        khh.magniCool = kaioken.returnMagniCool;
        se.magniCool = kaioken.returnMagniCool;
        teleport.leftC = teleport.maxC;
        teleport.returnSpeed = stat.moveSpeed;
    }

    void Start()
    {
        goku_SE = GetComponent<Goku_SE>();
        goku_UI = GameObject.Find("GokuUI").GetComponent<Goku_UI>();
        animator = GetComponent<Animator>();
        kaiokenAuraObj = transform.Find("KaiokenAura").gameObject;
        bC2D = transform.Find("Can'tPassTheWall").GetComponent<BoxCollider2D>();
        StartCoroutine(CoolDown_Q());
        StartCoroutine(CoolDown_W());
        StartCoroutine(CoolDown_E());
        StartCoroutine(CoolDown_Space());
    }

    void Update()
    {
        //딜레이X
        if(!cantAnythings)
        {
            UseSkill(CheckPushingButton());
            HandleInput(20, 20);
        }
        //딜레이O
        else
        {
            moveVt = Vector2.zero;
            pushKeys = 0;
        }

        RegenMp(stat.mana, stat.regenMana);
        goku_UI.OnViewHealthGauage(stat.health);
        goku_UI.OnViewManaGauage(stat.mana);

        //CoolDown(canUseKhh, canUseSe, canUseKaioken, canUseTeleport);
        goku_UI.OnViewAvoidanceGauage(teleport.maxC, teleport.leftC);

        if(moveVt != new Vector2(0, 0) && !cantAnythings && !guarding) animator.SetBool(hashMove, true);
        else animator.SetBool(hashMove, false);
    }

    void FixedUpdate()
    {
        Move();
    }

    public override void Move()
    {
        tr.Translate(moveVt * stat.moveSpeed * Time.fixedDeltaTime);
    }

    public override void UseSkill(int k)
    {
        switch(k)
        {
            case 0:
                animator.SetBool(hashGuard, false);
                break;
            //Q 사용
            case 1:
                if(canUseKhh && stat.mana >= khh.mana && !animator.GetBool(hashTeleportMode))
                {
                    animator.SetTrigger(hashKhh);
                    StartCoroutine(CoolDown_Q());

                    ////////////사운드 이펙트/////////////////
                    if(!animator.GetBool(hashKaioken))
                        goku_SE.NormalSkillSE(0);
                    else
                        goku_SE.KaiokenSkillSE(0);
                    ////////////사운드 이펙트/////////////////

                    stat.mana -= khh.mana;
                    cantAnythings = true;
                    canUseKhh = false;
                    khh.leftC = khh.maxC;
                }
                else
                {
                    pushKeys = 0;
                }
                break;

            //W 사용
            case 2:
                if(canUseSe && stat.mana >= se.mana && !animator.GetBool(hashTeleportMode))
                {
                    animator.SetTrigger(hashSe);
                    StartCoroutine(CoolDown_W());

                    ////////////사운드 이펙트/////////////////
                    if(!animator.GetBool(hashKaioken))
                        goku_SE.NormalSkillSE(1);
                    else
                        goku_SE.KaiokenSkillSE(1);
                    ////////////사운드 이펙트/////////////////

                    stat.mana -= se.mana;
                    cantAnythings = true;
                    canUseSe = false;
                    se.leftC = se.maxC;
                }
                else
                {
                    pushKeys = 0;
                }
                break;

            //E 사용
            case 3:
                if(canUseKaioken && !animator.GetBool(hashTeleportMode))
                {
                    animator.SetBool(hashKaioken, true);
                    StartCoroutine(CoolDown_E());
                    goku_UI.SetActiveUI(animator.GetBool(hashKaioken));
                    StartCoroutine(KaiokenMode());
                    ////////////사운드 이펙트/////////////////
                    goku_SE.NormalSkillSE(2);
                    ////////////사운드 이펙트/////////////////

                    cantAnythings = true;
                    canUseKaioken = false;                    //주석 해제하면 계왕권 모드 발동 직후 쿨다운
                    stat.moveSpeed = kaioken.increaseSpeed;
                    stat.regenMana = kaioken.increaseRegenMana;
                    kaioken.leftT = kaioken.maxT;
                    kaioken.leftC = kaioken.maxC;
                }
                else
                {
                    pushKeys = 0;
                }
                break;

            //Space 사용
            case 4:
                if(canUseTeleport)
                {
                    animator.SetTrigger(hashTeleport);
                    StartCoroutine(CoolDown_Space());
                    animator.SetBool(hashTeleportMode, true);
                    StartCoroutine(TeleportMode());
                    ////////////사운드 이펙트//////////////

                    ////////////사운드 이펙트//////////////

                    cantAnythings = true;
                    canUseTeleport = false;
                    stat.moveSpeed = teleport.increaseSpeed;
                    // teleport.leftT = teleport.maxT + 0.6f; // + 선 딜레이
                    // 코루틴 함수에서 실행
                    teleport.leftC = teleport.maxC;
                }
                else
                {
                    //0으로 강제초기화 하지 않으면 pushKeys가 4로 남아있을 수 있음
                    pushKeys = 0;
                }
                break;

            //F 사용
            case 5:
                animator.SetBool(hashGuard, true);
                //if(teleport.leftC >= teleport.maxC)
                teleport.leftC += Time.deltaTime * 2.0f;
                break;

        }
    }

    IEnumerator CoolDown_Q()
    {
        do
        {
            khh.leftC -= Time.deltaTime * khh.magniCool;
            goku_UI.CoolTimeUI_Khh();
            yield return null;

        } while(khh.leftC > 0.0f);

        canUseKhh = true;
        yield return null;
    }

    IEnumerator CoolDown_W()
    {
        do
        {
            se.leftC -= Time.deltaTime * se.magniCool;
            goku_UI.CoolTimeUI_SE();
            yield return null;

        } while(se.leftC > 0.0f);

        canUseSe = true;
        yield return null;
    }

    IEnumerator CoolDown_E()
    {
        do
        {
            kaioken.leftC -= Time.deltaTime;
            goku_UI.CoolTimeUI_Kaioken();
            yield return null;

        } while(kaioken.leftC > 0.0f);

        canUseKaioken = true;
        yield return null;
    }

    IEnumerator CoolDown_Space()
    {
        do
        {
            teleport.leftC -= Time.deltaTime;
            yield return new WaitWhile(() => pushKeys == 5);

        } while(teleport.leftC > 0.0f);

        canUseTeleport = true;
        yield return null;
    }

    IEnumerator KaiokenMode()
    {
        tag = "Untagged";                       //무적(쉴드)장착
        ApplyMagniCooldown();
        do
        {
            kaioken.leftT -= Time.deltaTime;    //kaioken.leftT 소모
            goku_UI.OnViewKaiokenGauage(kaioken.leftT);
            yield return null;

        } while(kaioken.leftT > 0.0f);
        //계왕권 남은시간이 모두 소모된다면
        tag = "Player";                         //무적(쉴드)해제
        RelieveMagniCoolDown();
        //canUseKaioken = false;                //쿨다운 시작, 주석 해제하면 계왕권 모드 종료 직후 쿨다운
        kaiokenAuraObj.SetActive(false);
        animator.SetBool(hashKaioken, false);   //계왕권 모드 종료
        goku_UI.SetActiveUI(animator.GetBool(hashKaioken));
        stat.moveSpeed = kaioken.returnSpeed;
        stat.regenMana = kaioken.returnRegenMana;
        yield return null;

    }

    void ApplyMagniCooldown()
    {
        khh.magniCool = kaioken.magni_Q_Cool;
        se.magniCool = kaioken.magni_W_Cool;
    }

    void RelieveMagniCoolDown()
    {
        khh.magniCool = kaioken.returnMagniCool;
        se.magniCool = kaioken.returnMagniCool;
    }

    IEnumerator TeleportMode()
    {
        tag = "Untagged"; bC2D.enabled = false; //무적
        teleport.leftT = teleport.maxT + 0.6f; // + 선 딜레이
        do
        {
            teleport.leftT -= Time.deltaTime;
            yield return null;

        } while(teleport.leftT > 0.0f);
        animator.SetTrigger(hashTeleportingIsOver);
        animator.SetBool(hashTeleportMode, false);
        tag = "Player";  bC2D.enabled = true;  //무적 해제
        stat.moveSpeed = (animator.GetBool(hashKaioken) == true) ? kaioken.increaseSpeed : teleport.returnSpeed;
        yield return null;

        animator.ResetTrigger(hashTeleportingIsOver);
        yield return null;
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        //모든 장애물에 피격 (노말 모드일 때만)
        if(coll.tag.StartsWith("Obstacle") && CompareTag("Player"))
        {
            stat.health -= 40.0f;
            if(stat.health <= 0.0f)
            {
                Dead();
            }
            coll.gameObject.SetActive(false);
        }

        //아이템 획득
        switch(coll.tag)
        {
            case "Item_Meat":
                if(stat.health < stat.maxHealth)
                {
                    stat.health += GameManager.instance.itemEffect.meatHp;
                    stat.health = (stat.health > stat.maxHealth) ? stat.maxHealth : stat.health;
                    coll.gameObject.SetActive(false);
                }
                break;
            case "Item_Apple":
                if(stat.mana < stat.maxMana)
                {
                    stat.mana += GameManager.instance.itemEffect.appleMp;
                    stat.mana = (stat.mana > stat.maxMana) ? stat.maxMana : stat.mana;
                    coll.gameObject.SetActive(false);
                }
                break;
        }
    }

    public override void Dead()
    {
        goku_SE.audioSource.Stop();
        Time.timeScale = 0.0f;
    }
}
