﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goku_Animator_State : StateMachineBehaviour
{
    private Goku goku;
    private GameObject kaiokenAuraObj;
    void Awake()
    {
        goku = GameObject.Find("Goku").GetComponent<Goku>();
        kaiokenAuraObj = GameObject.Find("Goku").transform.Find("KaiokenAura").gameObject;
    }

    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if(stateInfo.IsName("Guarding"))
            animator.SetBool("Guarding", true);

    }

    /*override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        goku.cantAnythings = true;
    }*/
    

    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        goku.cantAnythings = false;
        if(stateInfo.IsName("Kaioken"))
            kaiokenAuraObj.SetActive(true);
        else if(stateInfo.IsName("Guarding"))
            animator.SetBool("Guarding", false);

    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
