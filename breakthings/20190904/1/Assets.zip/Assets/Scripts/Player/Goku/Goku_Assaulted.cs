﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goku_Assaulted : MonoBehaviour
{
    private Goku goku;
    private Goku_SE goku_SE;
    private Animator animator;
    private Rigidbody2D rb2D;
    private Transform gokuTr;

    public enum StiffenState //경직 상태
    {
        None,
        Front,
        Down,
        Up
    }

    [System.Serializable]
    public struct StiffTime //경직 시간
    {
        [Tooltip("정면 경직시간")]
        public float byFront;
        [Tooltip("다운 경직시간")]
        public float byDown;
        [Tooltip("업 경직시간")]
        public float byUp;
        [Tooltip("에네르기파 계열 경직시간")]
        public float byKiBlast;
        [Tooltip("에네르기파 계열 허용시간")]
        public float duringFree;
        [Tooltip("Heavy 추가 경직시간")]
        public float addToHeavy;
        [Tooltip("낙법시간")]
        public float breakFall;
    }

    [System.Serializable]
    public struct KnockBackSpeed //넉백 속도
    {
        [Tooltip("정면으로 날라가는 속도")]
        public float front;
        [Tooltip("정면-선 항력")]
        public float front_Drag;
        [Tooltip("밑으로 날라가는 속도")]
        public float down;
        [Tooltip("아래-선 항력")]
        public float down_Drag;
        [Tooltip("위로 날라가는 속도")]
        public float up;
    }

    public StiffenState stiffen;
    public StiffTime stiffTime;
    public KnockBackSpeed knockBackSpeed;

    private float leftStiffTime;
    private float leftFreeTime;
    private bool overStiffenByKiBlast;

    private readonly int hashAss = Animator.StringToHash("Assaulted");
    private readonly int hashAss_Down = Animator.StringToHash("Assaulted_Down");
    private readonly int hashAss_Up = Animator.StringToHash("Assaulted_Up");
    private readonly int hashAss_KB = Animator.StringToHash("Assaulted_KiBlast");

    void Start()
    {
        goku = GameObject.Find("Goku").GetComponent<Goku>();
        goku_SE = GameObject.Find("Goku").GetComponent<Goku_SE>();
        animator = GameObject.Find("Goku").GetComponent<Animator>();
        rb2D = GameObject.Find("Goku").GetComponent<Rigidbody2D>();
        gokuTr = GameObject.Find("Goku").GetComponent<Transform>();
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        if(CompareTag("Untagged"))
        {
            Front_Or_Behind(gokuTr.position.x > coll.transform.position.x ? -1.0f : 1.0f);
            switch(coll.collider.tag)
            {
                case "Boss_Assault_Front_Light":
                    Damaged(5.0f);
                    animator.SetBool(hashAss, true);

                    rb2D.AddForce((coll.transform.position.x - this.transform.position.x >= 0.0f ? Vector2.left : Vector2.right) * knockBackSpeed.front);

                    stiffen = StiffenState.Front;
                    goku.cantAnythings = true;

                    StartCoroutine(CheckStiffenState(false));
                    goto case "Commonness";

                case "Boss_Assault_Front_Heavy":
                    Damaged(10.0f);
                    animator.SetBool(hashAss, true);

                    rb2D.drag = knockBackSpeed.front_Drag;
                    rb2D.AddForce((coll.transform.position.x - this.transform.position.x >= 0.0f ? Vector2.left : Vector2.right) * knockBackSpeed.front);

                    stiffen = StiffenState.Front;
                    goku.cantAnythings = true;

                    StartCoroutine(CheckStiffenState(true));
                    goto case "Commonness";

                case "Boss_Assault_Top_Heavy":
                    Damaged(10.0f);
                    animator.SetBool(hashAss_Down, true);

                    rb2D.drag = knockBackSpeed.down_Drag;
                    rb2D.AddForce(Vector2.down * knockBackSpeed.down);

                    stiffen = StiffenState.Down;
                    goku.cantAnythings = true;

                    StartCoroutine(CheckStiffenState(true));
                    goto case "Commonness";

                case "Boss_Assault_Bottom_Light":
                    Damaged(5.0f);
                    animator.SetBool(hashAss_Up, true);

                    rb2D.drag = 0.0f;
                    rb2D.AddForce((coll.transform.position.x - this.transform.position.x >= 0.0f ? new Vector2(-1.0f, 2.0f) : new Vector2(1.0f, 2.0f)) * knockBackSpeed.up);

                    stiffen = StiffenState.Up;
                    goku.cantAnythings = true;

                    StartCoroutine(CheckStiffenState(false));
                    goto case "Commonness";

                case "Commonness": //존재하는 태그는 아니지만 모든 보스 어썰트 태그에는 여기로 집결한다
                    StartCoroutine(goku_SE.AudioFadeOut());
                    break;
            }
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if(coll.CompareTag("Boss_KiBlast"))
        {
            if(CompareTag("Untagged"))
            {
                StartCoroutine(StiffenByKiBlast());
            }
        }
    }

    void OnTriggerStay2D(Collider2D coll)
    {
        if(coll.CompareTag("Boss_KiBlast"))
        {
            if(CompareTag("Untagged"))
            {
                animator.SetBool(hashAss_KB, true);
                Damaged(20.0f * Time.fixedDeltaTime);       //0.02초당 0.4의 데미지 -> 1초당 20데미지 ∴ 총 데미지합 : 32
            }
            else if(CompareTag("Player_Guard"))
            {
                Damaged(5.0f * Time.fixedDeltaTime);        //0.02초당 0.1의 데미지 -> 1초당 5데미지 ∴ 총 데미지합 : 8
                animator.SetBool(hashAss_KB, false);
                overStiffenByKiBlast = true;
                leftStiffTime = 0.0f;
                leftFreeTime = 0.0f;
                goku.cantAnythings = false;
            }
        }
    }

    void OnTriggerExit2D(Collider2D coll)
    {
        if(coll.CompareTag("Boss_KiBlast"))
        {
            animator.SetBool(hashAss_KB, false);
            overStiffenByKiBlast = true;
            leftStiffTime = 0.0f;
            leftFreeTime = 0.0f;
            goku.cantAnythings = false;
            goku.stat.health = Mathf.Round(goku.stat.health);
        }
    }

    IEnumerator CheckStiffenState(bool _isHeavy)
    {
        do
        {
            switch(stiffen)
            {
                case StiffenState.Front:
                    leftStiffTime += Time.deltaTime;
                    goku.cantAnythings = true;

                    if(leftStiffTime >= stiffTime.byFront + (_isHeavy == true ? stiffTime.addToHeavy : 0.0f))
                    {
                        stiffen = StiffenState.None;
                        animator.SetBool(hashAss, false);
                        goku.cantAnythings = false;
                        leftStiffTime = 0.0f;
                    }

                    break;

                case StiffenState.Down:
                    leftStiffTime += Time.deltaTime;
                    goku.cantAnythings = true;

                    if(leftStiffTime >= stiffTime.byDown + (_isHeavy == true ? stiffTime.addToHeavy : 0.0f) + stiffTime.breakFall)
                    {
                        stiffen = StiffenState.None;
                        goku.cantAnythings = false;
                        leftStiffTime = 0.0f;
                    }
                    else if(leftStiffTime >= stiffTime.byDown + (_isHeavy == true ? stiffTime.addToHeavy : 0.0f))
                    {
                        animator.SetBool(hashAss_Down, false);
                    }

                    break;

                case StiffenState.Up:
                    leftStiffTime += Time.deltaTime;
                    goku.cantAnythings = true;

                    if(leftStiffTime >= stiffTime.byUp + (_isHeavy == true ? stiffTime.addToHeavy : 0.0f))
                    {
                        stiffen = StiffenState.None;
                        animator.SetBool(hashAss_Up, false);
                        goku.cantAnythings = false;
                        leftStiffTime = 0.0f;
                    }

                    break;

                default:
                    break;
            }
            yield return null;

        } while(stiffen != StiffenState.None);
        rb2D.drag = 5.0f;
        yield return null;
    }

    IEnumerator StiffenByKiBlast()
    {
        do
        {
            if(leftStiffTime >= stiffTime.byKiBlast)
            {
                goku.cantAnythings = false;
                leftStiffTime = 0.0f;
                leftFreeTime = 0.0f;
            }
            else if(leftFreeTime < stiffTime.duringFree)
            {
                goku.cantAnythings = false;
                leftFreeTime += Time.deltaTime;
            }
            else if(leftFreeTime >= stiffTime.duringFree)
            {
                goku.cantAnythings = true;
                leftStiffTime += Time.deltaTime;
            }
            yield return null;

        } while(!overStiffenByKiBlast);

        overStiffenByKiBlast = false;
        yield return null;
    }

    void Damaged(float _damage)
    {
        goku.stat.health -= _damage;
        if(goku.stat.health <= 0.0f)
        {
            goku.Dead();
        }
    }

    void Front_Or_Behind(float x)
    {
        if(x >= 0) gokuTr.localScale = new Vector2(20, 20);
        else if(x < 0) gokuTr.localScale = new Vector2(-20, 20);
    }

}
