﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct GokuAudio
{
    public AudioClip[] normalSkill;
    public AudioClip[] kaiokenSkill;
}

public class Goku_SE : MonoBehaviour
{
    public GokuAudio gokuAudio;
    [System.NonSerialized] public AudioSource audioSource;

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
    }

    public void NormalSkillSE(int _skillNum)
    {
        var _sfx = gokuAudio.normalSkill[_skillNum];
        audioSource.PlayOneShot(_sfx, audioSource.volume);
    }
    
    public void KaiokenSkillSE(int _skillNum)
    {
        var _sfx = gokuAudio.kaiokenSkill[_skillNum];
        audioSource.PlayOneShot(_sfx, audioSource.volume);
    }

    public IEnumerator AudioFadeOut()
    {
        do
        {
            audioSource.volume -= 0.1f;
            yield return new WaitForSeconds(0.05f);
        } while(audioSource.volume > 0.0f);
        audioSource.Stop();
        audioSource.volume = 1.0f;
        yield return null;
    }
}
