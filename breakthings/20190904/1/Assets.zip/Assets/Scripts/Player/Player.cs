﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct PlayerStat
{
    public float health;
    public float maxHealth;
    public float mana;
    public float maxMana;
    public float regenMana;
    public float moveSpeed;
    [System.NonSerialized]
    public float returnSpeed;
}

public class Player : MonoBehaviour
{
    public PlayerStat stat;
    public GameObject assaultedObj;

    public bool cantAnythings;//스킬 사용시 딜레이
    public bool guarding;//가드시 true
    [System.NonSerialized] public Vector2 moveVt;    //최종 방향벡터
    [System.NonSerialized] public Vector2 moveDir;   //반환 방향벡터
    [System.NonSerialized] public int pushKeys;     //스킬버튼(0 = None, 1 = Q, 2 = W, 3 = E)

    public void HandleInput(float x, float y)
    {   
        moveVt = PoolInput(x, y);
    }

    public Vector3 PoolInput(float x, float y)
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        moveDir = new Vector2(h, v).normalized;
        if(h < 0) transform.localScale = new Vector3(-x, y, 0);
        else if(h > 0) transform.localScale = new Vector3(x, y, 0);

        return moveDir;
    }

    public virtual void Move()
    {
        transform.Translate(moveVt * stat.moveSpeed * Time.fixedDeltaTime);
    }

    public int CheckPushingButton()
    {
        if(Input.GetButtonDown("Q"))
        {
            pushKeys = 1;
        }
        else if(Input.GetButtonDown("W"))
        {
            pushKeys = 2;
        }
        else if(Input.GetButtonDown("E"))
        {
            pushKeys = 3;
        }
        else if(Input.GetButtonDown("Avoidance"))
        {
            pushKeys = 4;
        }
        else if(Input.GetButton("Guard"))
        {
            pushKeys = 5;
            //가드 시 이동 불가
            assaultedObj.tag = "Player_Guard";
            guarding = true;
            stat.moveSpeed = 0.0f;
        }
        else if(Input.GetButtonUp("Guard"))
        {
            //가드 해제시 이동 가능
            assaultedObj.tag = "Untagged";
            guarding = false;
            stat.moveSpeed = stat.returnSpeed;
        }
        else 
        {
            pushKeys = 0;
        }
        
        return pushKeys;
    }


    //체력,마나리젠
    public void RegenMp(float _mana, float _manaRegen)
    {
        _mana = (_mana >= stat.maxMana) ? stat.maxMana : _mana + Time.deltaTime * _manaRegen;
        stat.mana =  _mana;
    }

    /*//스킬 쿨다운
    public virtual void CoolDown(bool q, bool w, bool e, bool space)
    { }*/

    //스킬 사용시
    public virtual void UseSkill(int k)
    { }

    //사망
    public virtual void Dead()
    { }
}
