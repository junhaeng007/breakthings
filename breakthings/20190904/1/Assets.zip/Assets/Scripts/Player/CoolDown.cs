﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CoolDown : MonoBehaviour
{
    public void CoolTime (Image img, float maxCool, float leftCool)
    {
        img.fillAmount = leftCool / maxCool;
    }
}
