﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vegeta_Animator_State : StateMachineBehaviour
{
    private Vegeta vegeta;
    void Awake()
    {
        vegeta = GameObject.Find("Vegeta").GetComponent<Vegeta>();
    }
    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    //override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    //override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    
    //}

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if(stateInfo.IsName("Ready"))
            vegeta.overReady = true;
        else if(stateInfo.IsTag("Dash_WildHunt"))
        {
            if(stateInfo.IsName("WildHunt_RushPunch"))
                vegeta.wildHunt = Vegeta.Step_WildHunt.Kick;
            else if(stateInfo.IsName("WildHunt_Kick"))
                vegeta.wildHunt = Vegeta.Step_WildHunt.SledgeHammer;
            else if(stateInfo.IsName("WildHunt_SledgeHammer"))
                vegeta.wildHunt = Vegeta.Step_WildHunt.None;
        }
        else if(stateInfo.IsTag("Range"))
        {
            vegeta.bossTr.rotation = Quaternion.Euler(0, 0, 0);
        }
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
