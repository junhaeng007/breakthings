﻿using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;

public class Vegeta : MonoBehaviour
{
    public enum State
    {
        Delay,
        Move,
        Discover,
        Trace,
        Trace_Attack,
        Dash,
        Dash_Attack,
        Range_Attack
    }

    public enum Mode
    {
        None,
        Dash,
        Range
    }

    public enum Step_WildHunt
    {
        None,
        Rush_Attack,
        Kick,
        SledgeHammer
    }
   
    struct Coord //방향벡터, 좌표
    {
        public Vector2 moveDir;
        public float moveX;
        public float moveY;
        public Vector2 targetDir;
    }

    [System.Serializable]
    public struct Speed //속력
    {
        public float appearSpeed;
        public float moveSpeed;
        public float traceSpeed;
        public float dashSpeed;
        [Header("-WildHunt")]
        public float rushPunchSpeed;
        public float kickSpeed;
    }
    
    [System.Serializable]
    public struct Dist //사정거리
    {
        public float traceDist;
        public float trace_AttackDist;
        public float dash_AttackDist;

        [Header("-ReadOnly")]
        [ReadOnly, Tooltip("보스와 플레이어와의 거리, 설정금지")]
        public float gapPlayerDist;
        [ReadOnly, Tooltip("보스와 지정타겟의 거리, 설정금지")]
        public float gapTargetDist;
    }
    
    [System.Serializable]
    public struct TimeVariable //시간 변수
    {
        [Tooltip("등장 이후 몇 초 이후부터 시작할지 설정")]
        public float startNeedTime;
        [Tooltip("특정 행동 이후 몇 초 동안 지연시킬지 설정")]
        public float delayNeedTime;
        [Tooltip("Move 상태를 몇 초 동안 지속된 이후 대쉬모드로 변경될지 설정")]
        public float dashNeedTime;
        [Tooltip("Move 상태를 몇 초 동안 지속된 이후 레인지모드로 변경될지 설정(대쉬모드와 달리 다른 요소로 인한 초기화X)")]
        public float rangeNeedTime;

        [Header("-ReadOnly")]
        [ReadOnly, Tooltip("지연 시간")]
        public float delayTime;
        [ReadOnly, Tooltip("누적된 시간")]
        public float startTime;
        [ReadOnly, Tooltip("Move 상태가 지속된 시간(대쉬모드)")]
        public float dashTime;
        [ReadOnly, Tooltip("Move 상태가 지속된 시간(레인지모드)")]
        public float rangeTime;
    }

    [System.Serializable]
    public struct Damage
    {
        public float blowPunch;     //Boss_Assault_Front_Light
        public float sledgeHammer;  //Boss_Assault_Top_Heavy
        public float rushPunch;     //Boss_Assault_Front_Heavy
        public float kick;          //Boss_Assault_Bottom_Light
        public float galickGun;     //Boss_KiBlast
    }

    //상태를 저장할 변수
    public State state = State.Move;
    public Mode mode = Mode.None;
    public Step_WildHunt wildHunt = Step_WildHunt.None;
    private int assaultNum;
    private int dashNum;
    private int rangeNum;

    private Rigidbody2D rb2D;
    [System.NonSerialized]
    public Transform bossTr;
    private Transform playerTr;
    private Animator animator;

    //보스 이동 변수
    Coord coord;
    public Speed speed;

    //사정거리 변수
    public Dist dist;

    //시간 변수
    public TimeVariable time;

    //데미지
    public Damage damage;

    //Boolean 변수
    [System.NonSerialized]
    public bool overReady = false;   //준비 완료되면 true
    private bool bumpToWall = false; //벽에 부딪혔는 지 true
    private bool doTracing = false;  //추격 시작시 true, 추격 종료시 false
    private bool doDash_Attack = false;
    private bool isDelay = false;    //딜레이 타임일 때 true
    private bool isDie = false;      //보스 클리어시 true

    //애니메이터 컨트롤러에 정의한 파라미터의 해시값을 미리 추출
    private readonly int hashReady = Animator.StringToHash("Ready");
    private readonly int hashMove = Animator.StringToHash("Move");
    private readonly int hashDash = Animator.StringToHash("Dash");
    private readonly int hashBlowPunch = Animator.StringToHash("BlowPunch");
    private readonly int hashSledgeHammer = Animator.StringToHash("SledgeHammer");
    private readonly int hashWildHunt = Animator.StringToHash("WildHunt");
    private readonly int hashGalickGun = Animator.StringToHash("GalickGun");

    void Awake()
    {
        rb2D = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    void Start()
    {
        bossTr = transform;
        playerTr = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        bossTr.SetPositionAndRotation(new Vector2(-50.0f, 50.0f), Quaternion.Euler(0.0f, 0.0f, 0.0f));

        RandomDir();
        StartCoroutine(Appear_Vegeta());
    }
    
    void Update()
    {
        //벽에 부딪히면 방향 변경
        if(bumpToWall)
        {
            coord.moveDir = new Vector2(coord.moveX, coord.moveY);
            coord.moveDir.Normalize();
            bumpToWall = false;
        }
    }

    //베지터 등장
    IEnumerator Appear_Vegeta()
    {
        do
        {
            bossTr.Translate(Vector2.down * speed.appearSpeed * Time.deltaTime);
            yield return null;

        } while(bossTr.position.y > 0.0f);

        animator.SetTrigger(hashReady);
        StartCoroutine(Ready_Vegeta());
        yield return null;
    }

    IEnumerator Ready_Vegeta()
    {
        //준비(Vegeta_Animator_State)가 완료될 때까지 대기 = overReady가 true가 될 때까지 대기
        yield return new WaitUntil(() => overReady);
        do
        {
            time.startTime += Time.deltaTime;
            yield return null;

        } while(time.startTime < time.startNeedTime);

        StartCoroutine(CheckState());
        StartCoroutine(Action());
        StartCoroutine(CountDashTime());
        yield return null;
    }

    IEnumerator CheckState()
    {
        do
        {
            //보스 간의 거리를 계산
            dist.gapPlayerDist = Vector2.Distance(playerTr.position, bossTr.position);
            dist.gapTargetDist = Vector2.Distance(coord.targetDir, bossTr.position);

            //지연시간이 아닌 경우
            if(!isDelay)
            {
                switch(mode)
                {
                    //특정 모드가 아닌 경우
                    case Mode.None:
                        //사정거리 밖인 경우
                        if(dist.gapPlayerDist > dist.traceDist)
                        {
                            state = State.Move;
                        }
                        //추격 사정거리 이내인 경우
                        else if(dist.gapPlayerDist <= dist.traceDist && !doTracing)
                        {
                            state = State.Discover;
                            doTracing = true;
                        }
                        //타겟 포지션에 도착했을 때
                        else if(dist.gapTargetDist <= dist.trace_AttackDist && doTracing)
                        {
                            state = State.Trace_Attack;
                            doTracing = false;
                        }
                        break;

                    //대쉬 모드인 경우
                    case Mode.Dash:
                        //사정거리 밖인 경우
                        if(dist.gapPlayerDist > dist.dash_AttackDist && !doDash_Attack)
                        {
                            state = State.Dash;
                        }
                        //공격 사정거리 이내인 경우
                        else if(dist.gapPlayerDist <= dist.dash_AttackDist && !doDash_Attack)
                        {
                            state = State.Discover;
                            doDash_Attack = true;
                        }
                        break;

                    //레인지 모드인 경우
                    case Mode.Range:
                        state = State.Discover;
                        break;
                }
            }
            //지연시간인 경우
            else state = State.Delay;

            yield return null;


        } while(!isDie);
        yield return null;
    }

    IEnumerator Action()
    {
        do
        {
            switch(state)
            {
                case State.Delay:
                    mode = Mode.None;
                    doDash_Attack = false;

                    time.delayTime += Time.deltaTime;
                    if(time.delayTime >= time.delayNeedTime)
                    {
                        isDelay = false;
                        time.delayTime = 0.0f;
                    }
                    break;

                case State.Move:
                    SetHashMove(true);

                    Front_Or_Behind(coord.moveX);
                    bossTr.Translate(coord.moveDir * speed.moveSpeed * Time.deltaTime);
                    break;

                case State.Discover:
                    coord.targetDir = playerTr.position;
                    if(mode == Mode.None)
                    {
                        state = State.Trace;
                        goto case State.Trace;
                    }
                    else if(mode == Mode.Dash)
                    {
                        state = State.Dash_Attack;
                        goto case State.Dash_Attack;
                    }
                    else//if(mode == Mode.Range)
                    {
                        state = State.Range_Attack;
                        goto case State.Range_Attack;
                    }

                case State.Trace:
                    SetHashMove(true);

                    Front_Or_Behind(bossTr.position.x > coord.targetDir.x ? -1.0f : 1.0f);
                    bossTr.position = Vector2.MoveTowards(bossTr.position, coord.targetDir, speed.traceSpeed * Time.deltaTime);
                    break;

                case State.Trace_Attack:
                    SetHashMove(false);

                    assaultNum = Random.Range(0, 2);
                    switch(assaultNum)
                    {
                        case 0:
                            animator.SetTrigger(hashBlowPunch);
                            break;
                        case 1:
                            animator.SetTrigger(hashSledgeHammer);
                            break;
                    }

                    isDelay = true;
                    break;

                case State.Dash:
                    SetHashMove(false, true);

                    Front_Or_Behind(bossTr.position.x > playerTr.position.x ? -1.0f : 1.0f);
                    bossTr.position = Vector2.MoveTowards(bossTr.position, playerTr.position, speed.dashSpeed * Time.deltaTime);
                    break;

                case State.Dash_Attack:
                    SetHashMove(false);

                    dashNum = Random.Range(0, 1);
                    switch(dashNum)
                    {
                        case 0:
                            StartCoroutine(WildHunt());
                            break;

                    }
                    yield return new WaitUntil(() => isDelay == true);

                    break;

                case State.Range_Attack:
                    SetHashMove(false);

                    rangeNum = Random.Range(0, 1);
                    switch(rangeNum)
                    {
                        case 0:
                            Vector3 dir = (Vector3)coord.targetDir - bossTr.position;
                            float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

                            if(bossTr.localScale.x >= 0)
                                bossTr.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                            else
                                bossTr.rotation = Quaternion.AngleAxis(angle + 180.0f, Vector3.forward);

                            animator.SetTrigger(hashGalickGun);
                            break;
                    }
                    time.delayTime -= 3.2f;
                    isDelay = true;
                    break;
            }
            yield return null;

        } while(!isDie);
        yield return null;
    }

    IEnumerator WildHunt()
    {
        wildHunt = Step_WildHunt.Rush_Attack;
        animator.SetTrigger(hashWildHunt);
        do
        {
            bossTr.position = Vector2.MoveTowards(bossTr.position, coord.targetDir, speed.rushPunchSpeed * Time.deltaTime);
            Front_Or_Behind(bossTr.position.x > coord.targetDir.x ? -1.0f : 1.0f);
            yield return null;

        } while(wildHunt == Step_WildHunt.Rush_Attack);

        do
        {
            bossTr.position = Vector2.MoveTowards(bossTr.position, playerTr.position, speed.kickSpeed * Time.deltaTime);
            yield return null;

        } while(wildHunt == Step_WildHunt.Kick);

        float behind = bossTr.position.x > playerTr.position.x ? -10.0f : 10.0f;
        bossTr.position = new Vector2(playerTr.position.x + behind, playerTr.position.y + 15.0f);
        Front_Or_Behind(bossTr.position.x > playerTr.position.x ? -1.0f : 1.0f);
        yield return new WaitUntil(() => wildHunt == Step_WildHunt.None);
        
        isDelay = true;
        yield return null;
    }

    IEnumerator CountDashTime()
    {
        do
        {
            time.dashTime += Time.deltaTime;
            time.rangeTime += Time.deltaTime;
            if(state != State.Move)
            {
                time.dashTime = 0.0f;
                //Move 상태가 될 때까지 대기
                yield return new WaitUntil(() => state == State.Move);
            }

            if(time.rangeTime >= time.rangeNeedTime)
            {
                mode = Mode.Range;
                time.dashTime = 0.0f;
                time.rangeTime = 0.000000f;
                //Range 모드가 종료될 때 까지 대기 = 레인지모드가 아닐 때까지 대기
                yield return new WaitWhile(() => mode == Mode.Range);
            }
            else if(time.dashTime >= time.dashNeedTime)
            {
                mode = Mode.Dash;
                time.dashTime = 0.0f;
                //Dash 모드가 종료될 때 까지 대기 = 대쉬모드가 아닐 때까지 대기
                yield return new WaitWhile(() => mode == Mode.Dash);
            }
            yield return null;

        } while(!isDie);
        yield return null;
    }

    void RandomDir()
    {
        //이동 방향 무작위 설정
        while(true)
        {
            coord.moveX = Random.Range(0, 5);
            if(coord.moveX != 0.0f) break;
        }
        while(true)
        {
            coord.moveY = Random.Range(-5, 5);
            if(coord.moveY != 0.0f) break;
        }
        coord.moveDir = new Vector2(coord.moveX, coord.moveY);
        coord.moveDir.Normalize();
    }

    void Front_Or_Behind(float x)
    {
        if(x >= 0) bossTr.localScale = new Vector2(25, 25);
        else if(x < 0) bossTr.localScale = new Vector2(-25, 25);
    }

    void SetHashMove(bool _move, bool _dash = false)
    {
        animator.SetBool(hashMove, _move);
        animator.SetBool(hashDash, _dash);
    }

    void OnCollisionEnter2D(Collision2D coll)
    {
        //벽에 부딪혔을 때
        if(coll.collider.CompareTag("Wall"))
        {
            switch(coll.collider.name)
            {
                case "NorthWall":
                    if(coord.moveX < 0 && coord.moveY > 0)
                    {
                        coord.moveX = Random.Range(-5, 0);
                        coord.moveY = Random.Range(-5, 0);
                    }
                    else if(coord.moveX > 0 && coord.moveY > 0)
                    {
                        coord.moveX = Random.Range(1, 6);
                        coord.moveY = Random.Range(-5, 0);
                    }
                    break;

                case "EastWall":
                    if(coord.moveX > 0 && coord.moveY < 0)
                    {
                        coord.moveX = Random.Range(-5, 0);
                        coord.moveY = Random.Range(-5, 0);
                    }
                    else if(coord.moveX > 0 && coord.moveY > 0)
                    {
                        coord.moveX = Random.Range(-5, 0);
                        coord.moveY = Random.Range(1, 6);
                    }
                    break;

                case "SouthWall":
                    if(coord.moveX < 0 && coord.moveY < 0)
                    {
                        coord.moveX = Random.Range(-5, 0);
                        coord.moveY = Random.Range(1, 6);
                    }
                    else if(coord.moveX > 0 && coord.moveY < 0)
                    {
                        coord.moveX = Random.Range(1, 6);
                        coord.moveY = Random.Range(1, 6);
                    }
                    break;

                case "WestWall":
                    if(coord.moveX < 0 && coord.moveY > 0)
                    {
                        coord.moveX = Random.Range(1, 6);
                        coord.moveY = Random.Range(1, 6);
                    }
                    else if(coord.moveX < 0 && coord.moveY < 0)
                    {
                        coord.moveX = Random.Range(1, 6);
                        coord.moveY = Random.Range(-5, 0);
                    }
                    break;
            }
            bumpToWall = true;
        }
    }
}
